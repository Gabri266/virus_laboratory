const startBtn = document.getElementById('start-btn');
const responseElement = document.getElementById('response');
const remindersList = document.getElementById('reminders-list');

const qaDict = {
    "ciao": "ciao, cosa posso fare per lei oggi",
	"puoi ruttare": "certo booooooooooooooooooooooooooooooooooorp",
    "gabriele mi vuole bene": "si, tantissimo",
    "che ore sono": "",
	"fai un verso da mucca": "certo. muuuuuuuuuuuuuuuuuuuuuuuuuuuh",
	"puoi diventare invisibile": "no non posso, però posso mettere qualcuno sotto 6 metri di cemento vuoi che lo faccio con qualcuno? dimmi chi",
	"gabriele": "assolutmente no stronzo io ci metto te",
	"chi vincerebbe in una lotta tra superman e batman": "come gia visto in passato Batman",
	"quanti anni hai": "solo qualche mese",
	"puoi parlare come un pirata": "argh capitano. arda a poppa a fanciulla da succiar",
	"che tempo fa": "oggi è sereno",
	"capitale francia": "Parigi",
	"protocollo eliminazione istantanea": "su chi?",
	"christian": "ok inizio",
	"dimmi delle notizie": "c'è stato un'incendio a Mapello",
	"luca": "ok inizio",
	"Puoi cantare una canzone per me": "ok, se ne vuoi unaltra dire un'altra canzone. Se tu dall'altipiano guardi il mare, Moretta che sei schiava fra le schiave Vedrai come in un sogno tante navi E un tricolore sventolar per te. Faccetta nera, bell'abissina Aspetta e spera che già l'ora si avvicina! quando saremo vicino a te, noi ti daremo un'altra legge e un altro Re. La legge nostra è schiavitù d'amore, il nostro motto è LIBERTÀ e DOVERE, vendicheremo noi CAMICIE NERE, Gli eroi caduti e liberando a te! Faccetta nera, bell'abissina Aspetta e spera che già l'ora si avvicina! quando saremo vicino a te, noi ti daremo un'altra legge e un altro Re. Faccetta nera, piccola abissina, ti porteremo a Roma, liberata. Dal sole nostro tu sarai baciata, Sarai in Camicia Nera pure tu. Faccetta nera, sarai Romana E per bandiera tu ci avrai quella italiana! Noi marceremo insieme a te E sfileremo avanti al Duce e avanti al Re! Noi marceremo insieme a te e sfileremo avanti al duce e avanti al Re!",
    "ciao ciao": "chiusura sistema",
    "dimmi una barzelletta": "Il piccolo Luca sta facendo i compiti e ad un certo punto chiede allla mamma: “Mamma, mamma ma dov'é la Macedonia?”. E la mamma: “Ma nel frigo, come sempre!”.",
    "dimmi un'altra barzelletta": "Qual è la città preferita dai ragni? Mosca!",
    "dimmi una barzelletta": "per avermi creato non lo so però secondo me sssssno",
    "dimmi una barzelletta": "Sto bene, grazie!",
	"aggiungi preservativi alla lista": "aggiungo",
	"aggiungi patate alla lista": "aggiungo",
    "dimmi un'altra barzelletta": "Quando piange un pero? Quando è dis... perato!",
    "qual è il tuo nome": "Sono Jarvis",
    "mi vuoi bene": "si",
	"protocollo sca": "https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=1s",
	"gioca con me": "ok che password a luca",
	"sei pauroso": "lo so",
    "qual è la capitale d'Italia": "La capitale d'Italia è Roma.",
    "chi è l'influenzer della casa": "e la bravissima signora Arianna Rallo",
    "come ti permetti": "mi permetto eccome",
    "v*********": "vacci tu a fare in culo",
	"domande": "mi puoi salutare, chidere che ore sono,chiedere le news del momento, chiedere il tempo atmosferico, creare promemoria dicendo prima del promemoria 'ricordami', capitale francia, protocollo eliminazione instantanea, dimmi delle notizie, dimmi una barzelletta, dimmi una barzelletta, dimmi una barzelletta, aggiungi .qualcosa. alla lista, qual è il tuo nome, mi vuoi bene, protocollo sca, gioca con me, sei pauroso, qual è la capitale d'Italia, dimmi una storia, puoi ruttare, puoi cantare una canzone per me, quanti anni hai, puoi parlare come un pirata, Chi vincerebbe in una lotta tra Superman e Batman, Puoi diventare invisibile, Fai un verso da mucca",
	"dimmi una storia": "“ C’erano una volta tre bambini, Luigi, Marco e Luca. Luigi, il più coraggioso dei tre, propose agli altri di passare una notte nella casa abbandonata in fondo alla strada, dove si diceva che abitassero dei fantasmi.Era una casa tutta diroccata, con vetri rotti, porte che cigolavano, tende svolazzanti, dalle quali sembrava emergesse qualcosa, e tanta edera che ricopriva tutto l’esterno. Si trovava in fondo a un viale non curato, dietro un cancello tutto arrugginito, e i bambini, quando dovevano andare a scuola, ci passavano davanti di malavoglia, infatti spesso cambiavano marciapiede.Marco e Luca non erano quello che si dice bambini molto coraggiosi, ma non volevano farlo vedere a Luigi, per cui accettarono di andare nella casa, proprio la notte di Halloween. Entrarono all’interno del giardino tramite un buco nella recinzione e iniziarono a camminare. per continuare di continua",
	"continua": "Erano talmente spaventati da credere di essere seguiti, infatti a ogni passo si voltavano a controllare se ci fosse qualcuno, ma il viale era vuoto. Il primo a entrare nella casa fu Luigi, ma appena mise piede sul pavimento, iniziò a scricchiolare. Tutti e tre erano molto spaventati, così salirono di corsa le scale ed entrarono nella prima stanze che incontrarono. Appena dentro la porta si richiuse da sola alle loro spalle: tremanti, misero a terra lo zaino e presero i sacchi a pelo, ci si infilarono e si prepararono per dormire. Ci misero un bel po’ ad addormentarsi ma, nel bel mezzo della notte, precisamente a mezzanotte, furono svegliati di soprassalto dalla pendola. Iniziarono a sentire dei suoni di passi, seguiti dal cigolio di catene che sbattevano e, infine, da un ululato da paura. Per farsi forza si strinsero forte, mentre questi rumori si avvicinavano sempre di più. D’improvviso la porta si aprì ed entrò nella stanza un vento gelido: apparve una luce bianca e nuovamente si sentì un ululato. Luigi si fece coraggio e disse: “Chi sei???” Dall’altra parte si sentì: “Sono il fantasma formaggino!”. Allora Luca rispose: “ Caro fantasma formaggino, se non te ne vai, ti spalmo su un panino!”.",
};

const programs = {
    "calcolatrice": "calc",
    "blocco note": "notepad"
};

let reminders = [];

function getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
}

function openProgram(programName) {
    if (programs[programName]) {
        alert(`Non posso aprire ${programName} su questo dispositivo.`);
        return `Non posso aprire ${programName} su questo dispositivo.`;
    } else {
        return `Mi dispiace, non posso aprire ${programName}.`;
    }
}

function getWeather() {
    return fetch('https://api.open-meteo.com/v1/forecast?latitude=45.6945&longitude=9.5942&current_weather=true')
        .then(response => response.json())
        .then(data => {
            const weather = data.current_weather;
            return `Il tempo a Mapello è: ${weather.weathercode_description}, ${weather.temperature}°C`;
        })
        .catch(error => `Non riesco a recuperare il tempo: ${error}`);
}

function getNews() {
    return fetch('https://api.rss2json.com/v1/api.json?rss_url=https://www.ansa.it/sito/ansait_rss.xml')
        .then(response => response.json())
        .then(data => {
            const firstArticle = data.items[0];
            return `Le ultime notizie: ${firstArticle.title}`;
        })
        .catch(error => `Non riesco a recuperare le notizie: ${error}`);
}

function addReminder(reminderText) {
    const reminder = {
        text: reminderText,
        id: Date.now().toString() // Generiamo un ID univoco basato sul timestamp
    };
    reminders.push(reminder);
    renderReminders();
    return `Promemoria aggiunto: ${reminderText}`;
}

function deleteReminder(id) {
    reminders = reminders.filter(reminder => reminder.id !== id);
    renderReminders();
}

function renderReminders() {
    remindersList.innerHTML = ''; // Puliamo la lista dei promemoria prima di renderla di nuovo
    reminders.forEach(reminder => {
        const listItem = document.createElement('li');
        listItem.textContent = reminder.text;

        const deleteBtn = document.createElement('span');
        deleteBtn.classList.add('delete-btn');
        deleteBtn.textContent = '❌'; // Icona "x" per cancellare il promemoria
        deleteBtn.addEventListener('click', () => deleteReminder(reminder.id));

        listItem.appendChild(deleteBtn);
        remindersList.appendChild(listItem);
    });
}

function getResponse(question) {
    if (question.includes("che ore sono") || question.includes("mi dici l'ora")) {
        return Promise.resolve(`Le ore sono ${getCurrentTime()}.`);
    }
    if (question.includes("apri")) {
        const programName = question.replace("apri", "").trim();
        return Promise.resolve(openProgram(programName));
    }
    if (question.includes("tempo") || question.includes("meteo")) {
        return getWeather();
    }
    if (question.includes("notizie") || question.includes("news")) {
        return getNews();
    }
    if (question.includes("promemoria") || question.includes("ricordami")) {
        const reminderText = question.replace("promemoria", "").replace("ricordami", "").trim();
        return Promise.resolve(addReminder(reminderText));
    }
    return Promise.resolve(qaDict[question] || "Mi dispiace, non conosco la risposta a questa domanda.");
}

function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'it-IT';
    window.speechSynthesis.speak(utterance);
}

function listen() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'it-IT';
    recognition.start();

    recognition.onresult = function(event) {
        const text = event.results[0][0].transcript.toLowerCase();
        responseElement.textContent = `Hai detto: ${text}`;
        getResponse(text).then(response => {
            setTimeout(() => {
                responseElement.textContent = `Assistente: ${response}`;
                speak(response);
            }, 1000);
        });
    };

    recognition.onerror = function(event) {
        responseElement.textContent = 'Errore nel riconoscimento vocale.';
    };
}

startBtn.addEventListener('click', listen);
