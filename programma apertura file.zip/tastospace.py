import pyautogui, sys, time

while True:
	pyautogui.press('space')